package com.caopan.TrainSys.constant;

public class AuthResponseCode {

    public static final String TOKEN_IS_NULL = "918";
    public static final String TOKEN_IS_NULL_DESC = "token值为空";
    public static final String TOKEN_EXPIRED = "919";
    public static final String TOKEN_EXPIRED_DESC = "token值过期";
    public static final String TOKEN_INVALID = "920";
    public static final String TOKEN_INVALID_DESC = "token无效";


    public static final String USER_IS_STU = "1";
    public static final String USER_IS_STU_DESC = "用户为学生";
    public static final String USER_IS_SUPERVISOR = "2";
    public static final String USER_IS_SUPERVISOR_DESC = "用户为管理员";
    public static final String USER_NOT_AUTH = "201";
    public static final String USER_NOT_AUTH_DESC = "用户未认证，请认证登录";
    public static final String USER_AUTH_FAILED = "1001";
    public static final String USER_AUTH_FAILED_DESC = "用户认证失败";
}
