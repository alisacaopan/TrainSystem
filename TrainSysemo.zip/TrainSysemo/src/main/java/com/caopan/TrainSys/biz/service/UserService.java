package com.caopan.TrainSys.biz.service;

import com.caopan.TrainSys.constant.AuthResponseCode;
import com.appjishu.passport.service.TokenService;
import com.caopan.TrainSys.biz.dao.UserDao;
import com.caopan.TrainSys.model.LoginResult;
import com.caopan.TrainSys.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserDao userDao;

//    @Autowired
//    private TokenService tokenService;

    public LoginResult login(String openid) {

        User user = userDao.getUserByOpenId(openid);
        long userId = user.getId();
        String username = user.getName();

        String code = user.getRole();
        if (user.getIdCard().equals("") || user.getMobile().equals("")) {
            code = AuthResponseCode.USER_NOT_AUTH;
        }
        String token = "00000";

        LoginResult loginResult = new LoginResult();
        loginResult.setUserId(userId);
        loginResult.setToken(token);
        loginResult.setUsername(username);
        loginResult.setCode(code);
        return loginResult;
    }

}
