package com.caopan.TrainSys.biz.dao;

import com.caopan.TrainSys.model.User;
import org.apache.ibatis.annotations.Param;

import org.springframework.stereotype.Component;

@Component
public interface UserDao {
    Integer isert(User user);

    User getUserByIdcard(@Param("idCard") String idCard);

    User getUserBymobile(@Param("mobile") String mobile);

    User getUserByOpenId(@Param("openId") String openid);
}
