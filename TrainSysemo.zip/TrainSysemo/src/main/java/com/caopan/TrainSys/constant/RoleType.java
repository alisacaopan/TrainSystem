package com.caopan.TrainSys.constant;

public class RoleType {
    public static final int STUDENT = 1;
    public static final int SUPERVISOR = 2;
    public static final int MANAGE = 3;
}
